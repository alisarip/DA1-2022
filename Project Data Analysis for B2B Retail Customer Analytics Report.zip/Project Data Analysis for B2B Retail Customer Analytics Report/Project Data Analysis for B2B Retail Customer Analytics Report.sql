SELECT * FROM orders_1 LIMIT 5;
SELECT * FROM orders_2 LIMIT 5;
SELECT * FROM customer LIMIT 5;

SELECT
	SUM(quantity) AS total_penjualan,
	SUM(quantity * priceeach) AS revenue
FROM orders_1
WHERE STATUS='Shipped';

SELECT
	SUM(quantity) AS total_penjualan,
	SUM(quantity * priceeach) AS revenue
FROM orders_2
WHERE STATUS = 'Shipped';

SELECT 
	QUARTER,
	SUM(quantity) AS total_penjualan,
	SUM(quantity * priceeach) AS revenue
FROM 	(SELECT
			orderNumber,
			STATUS,
			quantity,
			priceEach,
			'1' AS QUARTER
		FROM orders_1
		UNION
		SELECT
			orderNumber,
			STATUS,
			quantity,
			priceEach,
			'2' AS QUARTER
		FROM orders_2)
		AS tabel_a
WHERE STATUS = 'Shipped'
GROUP BY QUARTER;


SELECT
	QUARTER,
	COUNT(DISTINCT customerID) AS total_customers
FROM
		(SELECT
			customerID,
			createDate,
			QUARTER(createDate) AS QUARTER
		FROM customer
		WHERE createDate BETWEEN '2004-01-01' AND '2004-06-30' ) AS tabel_b
GROUP BY QUARTER;


SELECT
	QUARTER,
	COUNT(DISTINCT customerID) AS total_customers
FROM (

		SELECT
			customerID,
			createDate,
			QUARTER(createDate) AS QUARTER
		FROM customer
		WHERE createDate BETWEEN '2004-01-01' AND '2004-06-30') AS tabel_b
WHERE customerID IN (
		SELECT
			DISTINCT customerID
		FROM orders_1
		UNION
		SELECT
			DISTINCT customerID
		FROM orders_2)
GROUP BY QUARTER;


SELECT * FROM (
	SELECT 
		categoryID,
		COUNT(DISTINCT orderNumber) AS total_order,
		SUM(quantity) AS total_penjualan
	FROM (
			SELECT
				productCode,
				orderNumber,
				quantity,
				STATUS,
				LEFT(productCode, 3) AS categoryID
			FROM  orders_2
			WHERE STATUS = 'Shipped' ) AS tabel_c
	GROUP BY categoryID) AS a
ORDER BY total_order DESC;


#Menghitung total unik customers yang transaksi di quarter_1
SELECT COUNT(DISTINCT customerID) AS total_customers FROM orders_1;
#output = 25

SELECT
	'1' AS QUARTER,
	COUNT(DISTINCT customerID) * 100/25 AS Q2
FROM orders_1
WHERE customerID IN (
	SELECT 
		DISTINCT customerID
	FROM orders_2);
